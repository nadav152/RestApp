package demo;

import java.util.Arrays;
import java.util.Date;

public class OperationBoundary {
	private String[] operationID;
	private String type;
	private String item;			/// FIX ItemBoundary
	private Date createdTimestamp;
	private UserBoundary invokedBy;
	private String[] operationAttributes;

	
	public OperationBoundary() {
		createdTimestamp = new Date();
	}

	public OperationBoundary(String space, String id, String type, String item, UserBoundary invokedBy, String[] attributes) {
		this();
		String[] operationID = {space, id};
		this.operationID = operationID;
		this.type = type;
		this.item = item;
		this.invokedBy = invokedBy;
		int keySize = attributes.length;
		int i = 0;
		String[] operationAttributes = new String [keySize];
		while (keySize > 0) {
			operationAttributes[i] = attributes[i];
			keySize--;
			i++;
		}
		this.operationAttributes = operationAttributes;
		
	}
	
	public String[] getOperationID() {
		return operationID;
	}

	public void setOperationID(String[] operationID) {
		this.operationID = operationID;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public UserBoundary getInvokedBy() {
		return invokedBy;
	}

	public void setInvokedBy(UserBoundary invokedBy) {
		this.invokedBy = invokedBy;
	}

	public String[] getOperationAttributes() {
		return operationAttributes;
	}

	public void setOperationAttributes(String[] operationAttributes) {
		this.operationAttributes = operationAttributes;
	}

	@Override
	public String toString() {
		return "OperationBoundary [operationID=" + Arrays.toString(operationID) + ", type=" + type + ", item=" + item
				+ ", createdTimestamp=" + createdTimestamp + ", invokedBy=" + invokedBy + ", operationAttributes="
				+ Arrays.toString(operationAttributes) + "]";
	}

}
